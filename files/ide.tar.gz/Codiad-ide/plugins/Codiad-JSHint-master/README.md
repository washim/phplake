#JSHint

Validate your JS code with JSHint.

- Supports .jshintrc files

##Installation

- Download the zip file and unzip it to your plugin folder.

##Requirements
- Requires modern browser with web worker.
  - FF >= 3.5
  - Chrome >= 4
  - IE >= 10
  - Opera >= 10.6
  - Safari >= 4
  - Details: [caniuse.com](http://caniuse.com/#feat=webworkers)

##Example

![JSHINT](http://andrano.de/Plugins/img/jshint.png)

##Credit

Uses [JSHint](http://www.jshint.com/).