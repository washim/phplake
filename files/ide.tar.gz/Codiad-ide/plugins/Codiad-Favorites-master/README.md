#Favorites

Save your favorite folders for quick access

##Installation

- Download the zip file and unzip it to your plugin folder.

##Channellog

- Sync your favorites with your Codiad server (Of course only if you enable plugin sync)
- Keep your favorites after refreshing your browser window

##Example
![Screen](http://andrano.de/Plugins/img/favorites.png "Screen")

##Attribution
Circle prohibited icon made by Yannick from Flaticon.com