# Together

This plugin adds Audio and Chat to Codiad
It is based on https://togetherjs.com/

*Note: Internet Explorer is not supported*

# Installation

- Download the zip file and extract it to your plugins folder
