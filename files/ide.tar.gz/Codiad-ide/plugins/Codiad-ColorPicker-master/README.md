# Color Picker

This plugin displays a HEX and RGB color chooser/modification utility through the [Codiad](http://www.codiad.com) user interface.

# Installation

- Download the zip file and extract it to your plugins folder
- Enable this plugin in the plugins manager in Codiad

