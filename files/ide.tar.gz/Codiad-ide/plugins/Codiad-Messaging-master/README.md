# Messaging
This plugin allows users to send messages to other users. In order to use, click on the sidebar menu item to send a message; new messages will be shown as tabs at the bottom of the screen.

# Installation

- Download the zip file and extract it to your plugins folder
- Enable this plugin in the plugins manager in Codiad

# Future improvements (in order of development)

- History deletion
- Ability to always view history
- Groups
