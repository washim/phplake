# Git Admin

This plugin allows to pull repos to your current project.

# Installation

- Download the zip file and extract it to your plugins folder
- Enable this plugin in the plugins manager in Codiad
