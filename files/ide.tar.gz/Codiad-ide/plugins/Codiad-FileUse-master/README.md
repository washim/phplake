#File Use
This plugin shows the users currently viewing a file on the bottom bar. The count is updated every 3 seconds, the user can click on it to show the usernames.

# Installation

- Download the zip file and extract it to your plugins folder
- Enable this plugin in the plugins manager in Codiad
