#Compress

Compress CSS and Javascript files with CSSmin and UglifyJS through the filemanager of Codiad

##Installation

- Download the zip file and unzip it to your plugin folder.

##More Information

[CSSmin](http://www.phpied.com/cssmin-js/ "CSSmin")

[UglifyJS](http://lisperator.net/uglifyjs/ "UglifyJS")